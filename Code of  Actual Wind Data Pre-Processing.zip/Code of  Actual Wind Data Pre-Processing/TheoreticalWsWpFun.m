function y= TheoreticalWsWpFun(x)
%���ٹ������۶�Ӧ���
    if x<=3 
        y=lin1(x);
    elseif  x>3  && x<=4
        y=lin2(x);
    elseif x>4  &&  x<=9.5
       y=lin3(x);
    elseif x>9.5  && x<=13
       y=lin4(x);
    else
       y=lin5(x);
    end
end

