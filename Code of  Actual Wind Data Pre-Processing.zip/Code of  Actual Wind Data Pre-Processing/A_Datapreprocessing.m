%% Data import
clear all;
close all;
raw_data=csvread('T1.csv',1,1); 
speed=raw_data(:,2);
real_power=raw_data(:,1);
theory_power=raw_data(:,3);

figure(1)
plot(speed);
axis([0 1000 0 20]);
legend('Actual wind speed series','FontSize',12);
xlabel('Time (10 min)','FontSize',12);
ylabel('Wind Speed (m/s)','FontSize',12);

figure(2)
plot(real_power);
axis([0 1000 0 3700]);
legend('Actual wind power series','FontSize',12);
xlabel('Time (10 min)','FontSize',12);
ylabel('Wind Power (KW)','FontSize',12);

figure(3)
plot(speed,real_power,'r.');
legend('Actual wind speed-power points','FontSize',12);
xlabel('Wind Speed','FontSize',12);
ylabel('Wind Power','FontSize',12);

% *************************************
index=find(real_power<=0);
real_power(index)=0.1;
% *************************************

%% Simple correction of abnormal wind speed
yuzhi=3;

record=1;
while size(record,2)~=0
 record=[];
for i=2:1:size(speed,1)-1
    if ((speed(i,1)-speed(i-1,1))*(speed(i,1)-speed(i+1,1))>0)&&((abs(speed(i,1)-speed(i-1,1))>yuzhi && abs(speed(i,1)-speed(i+1,1))>yuzhi) )
         if (speed(i,1)>speed(i-1,1)&& speed(i,1)>speed(i+1,1)) || (speed(i,1)<speed(i-1,1)&& speed(i,1)<speed(i+1,1))
        record=[record,i];
         end
    end 
end

for i=1:1:size(record,2)
    speed(record(1,i),1)=(speed(record(1,i)-1,1)+speed(record(1,i)+1,1))/2;
    theory_power(record(1,i),1)=TheoreticalWsWpFun(speed(record(1,i),1)); 
    real_power(record(1,i),1)=(real_power(record(1,i)-1,1)+real_power(record(1,i)+1,1))/2;
end

end

%% Simple correction of abnormal wind power
power_yuzhi=1.5;
record=1;
while size(record,2)~=0
 record=[];
for i=3:1:size(real_power,1)-1
    if real_power(i,1)<3590 && real_power(i,1)>2
      if (abs(real_power(i,1)-real_power(i-1,1))<power_yuzhi && abs(real_power(i,1)-real_power(i+1,1))<power_yuzhi)
          if (abs(real_power(i-1,1)-real_power(i-2,1))<power_yuzhi && abs(real_power(i-1,1)-real_power(i,1))<power_yuzhi) &&  (abs(real_power(i+1,1)-real_power(i,1))<power_yuzhi && abs(real_power(i+1,1)-real_power(i+2,1))<power_yuzhi)
              record=[record,i];  
          end
      elseif  abs(real_power(i,1)-real_power(i+1,1))<power_yuzhi && abs(real_power(i+1,1)-real_power(i+2,1))<power_yuzhi %&& abs(real_power(i+2,1)-real_power(i+3,1))<power_yuzhi
              record=[record,i]; 
      elseif  abs(real_power(i,1)-real_power(i-1,1))<power_yuzhi && abs(real_power(i-1,1)-real_power(i-2,1))<power_yuzhi %&& abs(real_power(i-2,1)-real_power(i-3,1))<power_yuzhi
              record=[record,i]; 
      end
    end
end
for i=1:1:size(record,2)
    if speed(record(1,i),1)<3  
    real_power(record(1,i),1)=lin1(speed(record(1,i),1));
    elseif speed(record(1,i),1)>3  &&  speed(record(1,i),1)<=4
       real_power(record(1,i),1)=lin2(speed(record(1,i),1));
     elseif speed(record(1,i),1)>4  &&  speed(record(1,i),1)<=9.5
         real_power(record(1,i),1)=lin3(speed(record(1,i),1));
     elseif speed(record(1,i),1)>9.5  &&  speed(record(1,i),1)<=13
         real_power(record(1,i),1)=lin4(speed(record(1,i),1));    
    else 
         real_power(record(1,i),1)=lin5(speed(record(1,i),1));
    end
end
end
%% Convert the data sampling rate from 10 min to 1h
Speedhour=zeros(floor(length(speed)/6),1); 
Powerhour=zeros(floor(length(speed)/6),1);
k=1;
for i=1:6:length(speed)-6             
    Speedhour(k,1)=speed(i,1);
    Powerhour(k,1)=real_power(i,1);
    for j=1:5
    Speedhour(k,1)=Speedhour(k,1)+speed(i+j,1);
    Powerhour(k,1)=Powerhour(k,1)+real_power(i+j,1);
    end
    k=k+1;
end
Speedhour=Speedhour./6;  
Powerhour=Powerhour./6;
%% Simple correction of abnormal wind speed
yuzhi=3;%3.2
record=1;
while size(record,2)~=0
 record=[];
for i=2:1:size(Speedhour,1)-1
    if ((Speedhour(i,1)-Speedhour(i-1,1))*(Speedhour(i,1)-Speedhour(i+1,1))>0)&&((abs(Speedhour(i,1)-Speedhour(i-1,1))>yuzhi && abs(Speedhour(i,1)-Speedhour(i+1,1))>yuzhi) )
         if (Speedhour(i,1)>Speedhour(i-1,1)&& Speedhour(i,1)>Speedhour(i+1,1)) || (Speedhour(i,1)<Speedhour(i-1,1)&& Speedhour(i,1)<Speedhour(i+1,1))
        record=[record,i];
         end
    end 
end

for i=1:1:size(record,2)
    Speedhour(record(1,i),1)=(Speedhour(record(1,i)-1,1)+Speedhour(record(1,i)+1,1))/2;
    Powerhour(record(1,i),1)=(Powerhour(record(1,i)-1,1)+Powerhour(record(1,i)+1,1))/2;
end

end



%% Simple correction of abnormal wind power
power_yuzhi=1.5;%3.2

record=1;
while size(record,2)~=0
 record=[];

for i=3:1:size(Powerhour,1)-1
    if Powerhour(i,1)<3590 && Powerhour(i,1)>2
      if (abs(Powerhour(i,1)-Powerhour(i-1,1))<power_yuzhi && abs(Powerhour(i,1)-Powerhour(i+1,1))<power_yuzhi)
          if (abs(Powerhour(i-1,1)-Powerhour(i-2,1))<power_yuzhi && abs(Powerhour(i-1,1)-Powerhour(i,1))<power_yuzhi) &&  (abs(Powerhour(i+1,1)-Powerhour(i,1))<power_yuzhi && abs(Powerhour(i+1,1)-Powerhour(i+2,1))<power_yuzhi)
              record=[record,i];  
          end
      elseif  abs(Powerhour(i,1)-Powerhour(i+1,1))<power_yuzhi && abs(Powerhour(i+1,1)-Powerhour(i+2,1))<power_yuzhi %&& abs(real_power(i+2,1)-real_power(i+3,1))<power_yuzhi
              record=[record,i]; 
      elseif  abs(Powerhour(i,1)-Powerhour(i-1,1))<power_yuzhi && abs(Powerhour(i-1,1)-Powerhour(i-2,1))<power_yuzhi %&& abs(real_power(i-2,1)-real_power(i-3,1))<power_yuzhi
              record=[record,i]; 
      end
    end
end

for i=1:1:size(record,2)
    if Speedhour(record(1,i),1)<3  
    Powerhour(record(1,i),1)=0.1;
    elseif Speedhour(record(1,i),1)>3  &&  Speedhour(record(1,i),1)<=4
       Powerhour(record(1,i),1)=lin2(Speedhour(record(1,i),1));
     elseif Speedhour(record(1,i),1)>4  &&  Speedhour(record(1,i),1)<=9.5
         Powerhour(record(1,i),1)=lin3(Speedhour(record(1,i),1));
     elseif Speedhour(record(1,i),1)>9.5  &&  Speedhour(record(1,i),1)<=13
         Powerhour(record(1,i),1)=lin4(Speedhour(record(1,i),1));    
    else 
         Powerhour(record(1,i),1)=3600;
    end
end
end

figure 
plot(Speedhour','b-');
legend('Actual wind speed series','FontSize',12);
xlabel('Time (1 hour)','FontSize',12);
ylabel('Wind Speed (m/s)','FontSize',12);
axis([0 1000 0 20]);
title({'Actual wind speed series after';'simple correction of outliers and resolution conversion'});

figure 
plot(Powerhour','b-');
legend('Actual wind power series','FontSize',12);
xlabel('Time (1 hour)','FontSize',12);
ylabel('Wind Power (KW)','FontSize',12);
axis([0 1000 0 3700]);
title({'Actual wind power series after';'simple correction of outliers and resolution conversion'});

figure 
plot(Speedhour',Powerhour','r.');
legend('Actual wind speed-power points','FontSize',12);
title({'Actual wind speed-power poinrs after';'simple correction of outliers and resolution conversion'});

% **************************************************
index=find(Speedhour>20);
Speedhour(index)=[];
Powerhour(index)=[];
index=find(Speedhour<2);
Speedhour(index)=[];
Powerhour(index)=[];
% **************************************************

%% Gaussian fitting bias value setting
Powerhour=Powerhour+50; 

%% Find the wind speed range suitable for Gaussian fitting.
index=find(speed>20);
speed(index)=[];
theory_power(index)=[];
index=find(speed<2);
speed(index)=[];
theory_power(index)=[];

%% Find the error points
index1=find(Speedhour<=3);Speed_fit_1=Speedhour(index1);Power_fit_1=Powerhour(index1);
index2=find( Speedhour >3 & Speedhour<=4);Speed_fit_2=Speedhour(index2);Power_fit_2=Powerhour(index2);
index3=find( Speedhour >4 & Speedhour<=9.5);Speed_fit_3=Speedhour(index3);Power_fit_3=Powerhour(index3);
index4=find( Speedhour >9.5 & Speedhour<=13);Speed_fit_4=Speedhour(index4);Power_fit_4=Powerhour(index4);
index5=find(Speedhour>13);Speed_fit_5=Speedhour(index5);Power_fit_5=Powerhour(index5);
error_value=0.4;
index1_bad=find(abs((Power_fit_1-new_TheoreticalWsWpFun(Speed_fit_1))./new_TheoreticalWsWpFun(Speed_fit_1))>error_value);
index2_bad=find(abs((Power_fit_2-new_TheoreticalWsWpFun(Speed_fit_2))./new_TheoreticalWsWpFun(Speed_fit_2))>error_value);
index3_bad=find(abs((Power_fit_3-new_TheoreticalWsWpFun(Speed_fit_3))./new_TheoreticalWsWpFun(Speed_fit_3))>error_value);
index4_bad=find(abs((Power_fit_4-new_TheoreticalWsWpFun(Speed_fit_4))./new_TheoreticalWsWpFun(Speed_fit_4))>error_value);
index5_bad=find(abs((Power_fit_5-new_TheoreticalWsWpFun(Speed_fit_5))./new_TheoreticalWsWpFun(Speed_fit_5))>error_value);

figure 
H1=plot(Speedhour',Powerhour','b.');
title({'Actual wind speed-power points';' after Gauss identification'});
hold on;
H2=plot(Speed_fit_1(index1_bad),Power_fit_1(index1_bad),'g.');
hold on;
plot(Speed_fit_2(index2_bad),Power_fit_2(index2_bad),'g.');
hold on;
plot(Speed_fit_3(index3_bad),Power_fit_3(index3_bad),'g.');
hold on;
plot(Speed_fit_4(index4_bad),Power_fit_4(index4_bad),'g.');
hold on;
plot(Speed_fit_5(index5_bad),Power_fit_5(index5_bad),'g.');
hold on;
H3=plot(0:0.05:20,new_TheoreticalWsWpFun(0:0.05:20),'r-','linewidth',1.5);
legend([H1,H2,H3],{'Reasonable points','Error points','Gaussian fitting curve'},'FontSize',12);
%% Correct the error points
Index=[];
InterpolationRange=0.05;
real_power=Powerhour;
Power_revise=Powerhour;
speed=Speedhour;
for i=1:1:size(speed,1)
        if abs((real_power(i,1)-new_TheoreticalWsWpFun(speed(i,1)))/new_TheoreticalWsWpFun(speed(i,1)))>error_value
            index=find(abs(speed-speed(i,1))<InterpolationRange & (abs((real_power-new_TheoreticalWsWpFun(speed(i,1)))./new_TheoreticalWsWpFun(speed(i,1)))<=error_value));
            Power_revise(i,1)=mean(real_power(index));
            Index=[Index,i];
        end
end
figure 
H4=plot(speed',Power_revise','b.');
hold on;
H5=plot(speed(Index,1),Power_revise(Index,1),'yo');
hold on;
H6=plot(0:0.05:20,new_TheoreticalWsWpFun(0:0.05:20),'r-','linewidth',1);
legend([H4,H5,H6],{'Reasonable points','Corrected points','Gaussian fitting curve'},'FontSize',12);
title({'Actual wind speed-power points'; 'after correction'});


Speedhour=speed;
Powerhour=Power_revise;
Powerhour=Powerhour-50;

%% Output of Actual Wind Data Pre-Processing
figure 
plot(Speedhour',Powerhour','b.');
title({'Actual wind speed-power points';'after Actual Wind Data Pre-Processing'});

save Speedhour.mat Speedhour;
save Powerhour.mat Powerhour;