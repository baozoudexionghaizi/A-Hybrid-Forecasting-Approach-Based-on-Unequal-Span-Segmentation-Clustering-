function y= lin4(x)
%UNTITLED �˴���ʾ�йش˺�����ժҪ
       p1 =       10.86  ;
       p2 =      -475.3  ;
       p3 =        6869  ;
       p4 =  -2.923e+04  ;


y = p1*x.^3 + p2*x.^2 + p3*x + p4;
end

