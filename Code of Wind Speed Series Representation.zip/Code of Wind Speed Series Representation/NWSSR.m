function  [z_iter,z_final,pos_final,optimal_pos,modes,PS,OptimizationRecord]=NWSSR_good(data)

%% ****************************Default Parameters************************

Nstd = 0.2;
NR = 20;
MaxIter = 500;
run=1;

%% ***************************CEEMD**************************
global Modes 

[modes]=ceemd(data,Nstd,NR,MaxIter);

Modes=modes;
%% ****************************Commonly used variables************************
global Data

Data=data;


Data_length=size(data,2);
modes_size=size(modes,1);

global OptimizationRecord 
OptimizationRecord=[];

%% **********************Find Optimization Lower Bound ***********************
global OptimizationLowerBound 

RestructureData=modes(modes_size,:);        
x=1:1:Data_length;
RestructureData_fit= interp1(x([1,end]),RestructureData([1,end]),1:1:Data_length);
RMSE=sqrt(sum((data-RestructureData_fit).^2)/Data_length); 

OptimizationLowerBound=[modes_size,0,RMSE];

%% **********************Find Optimization upper Bound ************************************

global OptimizationUpperBound 
RestructureData=sum(modes); 

% *********** Find all extreme points ************************************

IndMin=find(diff(sign(diff(RestructureData)))>0)+1;
indMin=[IndMin;ones(1,size(IndMin,2))*-1];
IndMax=find(diff(sign(diff(RestructureData)))<0)+1;
indMax=[IndMax;ones(1,size(IndMax,2))*1];
Ind=[indMin,indMax];
[~,index]=sort(Ind(1,:));
Ind=Ind(:,index);
Ind=[1,Ind(1,:),Data_length];
if size(unique(Ind),2)~=size(Ind,2)
   [~,index1]=unique(Ind,'first');
   Ind=Ind(index1);
end
RestructureData_fit= interp1(Ind,RestructureData(Ind),1:1:Data_length);
RMSE=sqrt(sum((data-RestructureData_fit).^2)/Data_length); 
OptimizationUpperBound=[1,size(Ind,2),RMSE];

%% ***************************
PS=[OptimizationLowerBound(1,2:end);OptimizationUpperBound(1,2:end)];

%% ********************* Optimization process of DFPSO **********************

% parameter setting of DFPSO
nx=3;
np=25; % Number of search agents
maxit=10; % Maximum number of iterations
epsilon=eps; % This parameter must be either set to eps (typically for the uni-modal functions) or zero (typically for the multi-modal or complex functions)
k_max=0.9; % Upper bound of the inertia weight
k_min=0.4; % Lower bound of the inertia weight

lvbo_number=[1,modes_size];
T_v=[0,max(RestructureData(Ind))-min(RestructureData(Ind))];
T_t=[min(Ind(1,2:end)-Ind(1,1:end-1)),max(Ind(1,2:end)-Ind(1,1:end-1))];
varmax=[lvbo_number(2),T_v(2),T_t(2)]; % Upper bound defined for the positions which can generally be a desired vector
varmin=[lvbo_number(1),T_v(1),T_t(1)]; % Lower bound defined for the positions which can generally be a desired vector
limvel=1; % A ratio of the maximum distance in the search space to form the maximum velocity 
velmax=limvel*(varmax-varmin); % Upper bound defined for the velocities
velmin=-velmax; % Lower bound defined for the velocities


for nrun=1:run
[z_iter,z_final,pos_final,optimal_pos]=DFPSO(np,nx,maxit,varmax,varmin,velmax,velmin,epsilon,k_max,k_min,@Fitness_F);    
     z_iter_main(nrun,1:maxit)=z_iter(1:maxit);
     z_final_main(nrun)=z_final;
     pos_final_main(nrun,1:nx)=pos_final(1:nx);
end


disp(['The final statistical results calculated when implementing the DFPSO algorithm for ',num2str(run),' times are as follows:']);
disp(['The average of the final objective function values calculated over ',num2str(run),' times = ',num2str(mean(z_final_main(1:run)))]);
disp(['The median of the final objective function values calculated over ',num2str(run),' times = ',num2str(median(z_final_main(1:run)))]);
disp(['The best of the final objective function values calculated over ',num2str(run),' times = ',num2str(min(z_final_main(1:run)))]);

% Plot the chart of the objective function values obtained by DFPSO over the course of iterations
for i=1:maxit
    x1(i)=i;sum1=0;
    for j=1:run
        sum1=sum1+z_iter_main(j,i);
    end
    y1(i)=sum1/run;
end


end

