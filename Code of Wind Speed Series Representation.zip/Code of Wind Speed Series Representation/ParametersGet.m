function [A,B,fit_output] = jieguo(pp)
%JIEGUO �˴���ʾ�йش˺�����ժҪ
global Modes  
modes=Modes;

global Data  
data=Data;

global OptimizationUpperBound 
optimizationUpperBound=OptimizationUpperBound;

global OptimizationLowerBound 
optimizationLowerBound=OptimizationLowerBound;

global OptimizationRecord 


modes_size=size(modes,1);
Data_length=size(data,2);


Tv=pp(2); 
Tt=pp(3); 

if round(pp(1))==modes_size   
    RestructureData=modes(end,:); 
else
    RestructureData=sum(modes(round(pp(1)):end,:)); 
end

% *********** Find all extreme points ************************************

IndMin=find(diff(sign(diff(RestructureData)))>0)+1;
indMin=[IndMin;ones(1,size(IndMin,2))*-1];
IndMax=find(diff(sign(diff(RestructureData)))<0)+1;
indMax=[IndMax;ones(1,size(IndMax,2))*1];
Ind=[indMin,indMax];
[~,index]=sort(Ind(1,:));
Ind=Ind(:,index);


if size(Ind,2)>=2
    

record=[];
for i=2:1:size(Ind,2)-1
    if (abs(Ind(1,i)-Ind(1,i-1))<=Tt && abs(RestructureData(1,Ind(1,i))-RestructureData(1,Ind(1,i-1)))<Tv) || (abs(Ind(1,i)-Ind(1,i+1))<=Tt && abs(RestructureData(1,Ind(1,i))-RestructureData(1,Ind(1,i+1)))<Tv)
        record=[record,i];
    end  
end
record_1=[];
for i=1:1:size(record,2)
    if Ind(2,record(1,i))==-1
        if RestructureData(1,Ind(1,record(1,i)-1))>RestructureData(1,Ind(1,record(1,i)+1))
        record_1=[record_1,record(1,i)+1];
        else
        record_1=[record_1,record(1,i)-1];
        end
    else
        if RestructureData(1,Ind(1,record(1,i)-1))>RestructureData(1,Ind(1,record(1,i)+1))
        record_1=[record_1,record(1,i)-1];
        else
        record_1=[record_1,record(1,i)+1];
        end     
    end
end
Ind(:,record_1)=[];
% ȥ������ͬ�༫ֵ��
%�ҵ����ڵ�
record_2=[];
for i=1:1:size(Ind,2)-1
    if Ind(2,i)==Ind(2,i+1)
        record_2=[record_2,[i ;Ind(2,i) ]];
    end
end
%�ҵ��Ϻõĵ�
record_3=[];
for i=1:1:size(record_2,2)
    if Ind(2,record_2(1,i))==1
        
       if RestructureData(1,Ind(1,record_2(1,i)))>RestructureData(1,Ind(1,record_2(1,i)+1))
           record_3=[record_3,record_2(1,i)+1];
       else
           record_3=[record_3,record_2(1,i)];
       end
       
    else
        if RestructureData(1,Ind(1,record_2(1,i)))>RestructureData(1,Ind(1,record_2(1,i)+1))
           record_3=[record_3,record_2(1,i)];
       else
           record_3=[record_3,record_2(1,i)+1];
       end
        
    end
end
Ind(:,record_3)=[];
% �����⣺record_4Ϊ�յĻ�֤������
record_4=[];
for i=1:1:size(Ind,2)-1
    if Ind(2,i)==Ind(2,i+1)
        record_4=[record_4,[i ;Ind(2,i) ]];
    end
end

% ʵ�����ݼ���Ѱ��
Ind=[[1 ;-1],Ind];
record_5=[];
for i=2:1:size(Ind,2)-1
    if (RestructureData(1,Ind(1,i))>RestructureData(1,Ind(1,i-1))) && (RestructureData(1,Ind(1,i))>RestructureData(1,Ind(1,i+1))) %����ֵ��
      [~,index]=max(data(1,Ind(1,i-1):1:Ind(1,i+1)));
      xuhao=Ind(1,i-1):1:Ind(1,i+1);
      record_5=[record_5,xuhao(index)];
    else
       [~,index]=min(data(1,Ind(1,i-1):1:Ind(1,i+1)));
      xuhao=Ind(1,i-1):1:Ind(1,i+1);
      record_5=[record_5,xuhao(index)];
    end 
end
Ind=record_5;

if Ind(1)~=1 && Ind(end)~=Data_length
Ind=[1,Ind,size(data,2)];
end

if Ind(1)==1 && Ind(end)~=Data_length
Ind=[Ind,size(data,2)];
end

if Ind(1)~=1 && Ind(end)==Data_length
Ind=[1,Ind];
end



%% ***************************���Խ���**************************

if size(unique(Ind),2)~=size(Ind,2)
   [~,index]=unique(Ind,'first');
   Ind=Ind(index);
end

RestructureData_fit= interp1(Ind,data(Ind),1:1:Data_length);
RMSE=sqrt(sum((data-RestructureData_fit).^2)/Data_length); 

if RMSE>optimizationLowerBound(1,3)
    RMSE=optimizationLowerBound(1,3);
end
A=size(Ind,2);
B=RMSE;
fit_output=RestructureData_fit;
else

Ind=[1,Data_length];
RestructureData_fit = interp1(Ind(1,:),data(Ind(1,:)),1:1:Data_length);
RMSE=sqrt(sum((data-RestructureData_fit).^2)/Data_length); 

if RMSE>optimizationLowerBound(1,3)
    RMSE=optimizationLowerBound(1,3);
end

A=size(Ind,2);
B=RMSE;
fit_output=RestructureData_fit;
end


end

