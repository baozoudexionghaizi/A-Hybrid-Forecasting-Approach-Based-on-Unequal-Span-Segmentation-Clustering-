clear all;
close all;
load ('Data/Speedhour.mat');
Speedhour=Speedhour';

[z_iter,z_final,pos_final,optimal_pos,modes,PS,OptimizationRecord]=NWSSR(Speedhour);

z_iter=z_iter(:,1);
pp=pos_final(:,1)';
[A,B,fit_output] = ParametersGet(pp);

figure
plot(z_iter,'r-','LineWidth',1.5);
box on;
ylabel('Rising rate of the deviation','FontSize',18);
xlabel('Iteration','FontSize',18);
legend('R');
axis([1 length(z_iter) z_iter(end) z_iter(1)]);

figure
plot(round(optimal_pos(:,1))-1,'b-','LineWidth',1.5);
hold on;
plot(optimal_pos(:,2),'g-','LineWidth',1.5);
hold on;
plot(optimal_pos(:,3),'m-','LineWidth',1.5);
box on;
ylabel('Value of the parameter','FontSize',18);
xlabel('Iteration','FontSize',18);
legend('m','T_v','T_t');

figure
H1=plot(PS(:,1),PS(:,2),'ro','LineWidth',2,'Markersize',8);
hold on;
H2=plot(OptimizationRecord(:,4),OptimizationRecord(:,5),'bo','LineWidth',0.5,'Markersize',8);
hold on;
H3=plot(A,B,'go','LineWidth',2,'Markersize',8);
hold on;
H4=plot([PS(1,1);A],[PS(1,2);B],'r-.','LineWidth',1);
hold on;
H5=plot([PS(2,1);A],[PS(2,2);B],'r-.','LineWidth',1);
legend([H1,H2,H3],{'Boundary solutions','Searched solutions','Optimized solution'},'FontSize',12);
box on;
ylabel('Deviation (KW)','FontSize',12);
xlabel('The number of the piecewise points','FontSize',12);


figure
plot(Speedhour,'b-');
hold on;
plot(fit_output,'r-');
legend('Actual wind speed series','Wind speed major variation trend','FontSize',12);
xlabel('Time (hour)','FontSize',12);
ylabel('Wind Speed','FontSize',12);









