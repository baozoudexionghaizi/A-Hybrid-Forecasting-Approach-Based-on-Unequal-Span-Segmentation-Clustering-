function [mutation_population_variation,COST]= Segmentation3D(mutation_population_variation,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,WSMVT)
%% *******The function of Segmentation3D is to optimize the position of two cutting point*****************
% mutation_population_variation: Binary array of cut points of the wind speed major variation trend (WSMVT).
% COST: shape quality evaluation value after after moving two cut points.
% recut: Three consecutive cut points A, B, and C of mutation_population_variation.
% center_index: Indexes of corresponding centers of segments AB and BC.
% repopulation_center: Shape centers.
% repopulation_U: Membership matrix provided by FCM.
% SEG_up: Maximum length of segment.
% SEG_down: Minimum length of segment.

   %**********************Calculate shape quality evaluation value efore moving two cut points***************************************
   [vale,index]=max(repopulation_U(:,reSegpointsnumber));%ȷ���������ηֱ�������һ��
   left=dtw(WSMVT(1,recut(1):recut(2)),repopulation_center.(['center' num2str(index(1))]),0); %���������ڴ�������ƶ�
   right=dtw(WSMVT(1,recut(2):recut(3)),repopulation_center.(['center' num2str(index(2))]),0); %����Ҷ����ڴ�������ƶ�
    cost=(left+right+abs(left-right))/2; 
   allcost=[];
    %******************Bayesian 2-dimensional optimization****************************************************
    global Recut3D;
    Recut3D=recut;
    var1 = optimizableVariable('vx',[recut(1)+SEG_down-1,recut(1)+SEG_up-1]);
    var2 = optimizableVariable('vy',[recut(3)-SEG_up+1,recut(3)-SEG_down+1]);
    fun = @(x) my_sixmin3D(x.vx, x.vy,WSMVT,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,index);
    results = bayesopt(fun,[var1, var2],'PlotFcn',[],'Verbose',0,'MaxObjectiveEvaluations',10,'XConstraintFcn',@xconstraint3D);
    x = results.XAtMinObjective{1,:}; 
    y = results.MinObjective; 
   %************************************************************************************
   if y>cost
       COST=cost;
   else
       mutation_population_variation(1,recut(2))=0; % Eliminate the original cut point.
       mutation_population_variation(1,round(x(1,1)))=1; % Reset one cut point
       mutation_population_variation(1,round(x(1,2)))=1; % Reset the other cut point
       COST=y;
   end
end

