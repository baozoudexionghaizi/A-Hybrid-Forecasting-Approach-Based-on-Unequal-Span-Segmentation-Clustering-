function z = my_sixmin2D(x,WSMVT,recut,repopulation_center,repopulation_U)
%% *******The function of Bayesian 1-dimensional optimization*****************
% x: Expected cut point searched by Bayesian 2-dimensional optimization
% z: shape quality evaluation value after after moving a cut point.
% recut: Three consecutive cut points A, B, and C of mutation_population_variation.
% repopulation_center: Shape centers.
% repopulation_U: Membership matrix provided by FCM.

   x=round(x);
   allcost=[];
   Allcost=[];
   for i=1:1:size(repopulation_U,1)
    left=dtw(WSMVT(1,recut(1):x),repopulation_center.(['center' num2str(i)]),0); 
     for j=1:1:size(repopulation_U,1)
      right=dtw(WSMVT(1,x:recut(3)),repopulation_center.(['center' num2str(j)]),0); 
       allcost=[allcost; (left+right+abs(left-right))/2   i j x left right]; 
     end
       Allcost=[Allcost;allcost ];
       allcost=[];
   end
   z=min(Allcost(:,1));
  
end

