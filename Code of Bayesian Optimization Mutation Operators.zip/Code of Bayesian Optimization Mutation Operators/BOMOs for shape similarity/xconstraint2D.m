function tf = xconstraint2D(x)
 %% This function is the range constraint condition of x of Bayesian 1-dimensional optimization.
 global recut;
tf1 = round(x.vx )-recut(1,1)+1>=8;
tf2 = round(x.vx )-recut(1,1)+1<=24;
tf3 = recut(1,3)-round(x.vx)+1>=8;
tf4 = recut(1,3)-round(x.vx)+1<=24;
tf = tf1 & tf2 & tf3 & tf4 ;
end

