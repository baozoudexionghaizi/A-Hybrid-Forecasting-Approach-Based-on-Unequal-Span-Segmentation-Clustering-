function tf = xconstraint3D(x)
 %% This function is the range constraint condition of x,y of Bayesian 2-dimensional optimization.
global recut;
tf1 = round(x.vx )-recut(1,1)+1>=8;
tf2 = round(x.vx )-recut(1,1)+1<=24;
tf3 = round(x.vy)-round(x.vx)+1>=8;
tf4 = round(x.vy)-round(x.vx)+1<=24;
tf5 = recut(1,3)-round(x.vy)+1>=8;
tf6 = recut(1,3)-round(x.vy)+1<=24;
tf7 = round(x.vx ) < round(x.vy);
tf = tf1 & tf2 & tf3 & tf4 & tf5 & tf6 & tf7 ;
end
