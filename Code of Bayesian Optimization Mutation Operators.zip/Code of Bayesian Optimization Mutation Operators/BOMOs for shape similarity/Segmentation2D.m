function [mutation_population_variation,COST]= Segmentation2D(mutation_population_variation,recut,center_index,repopulation_center,repopulation_U,SEG_up,SEG_down,WSMVT)

%% *******The function of Segmentation2D is to optimize the position of one cutting point*****************
% mutation_population_variation: Binary array of cut points of the wind speed major variation trend (WSMVT).
% COST: shape quality evaluation value after after moving a cut point.
% recut: Three consecutive cut points A, B, and C of mutation_population_variation.
% center_index: Indexes of corresponding centers of segments AB and BC.
% repopulation_center: Shape centers.
% repopulation_U: Membership matrix provided by FCM.
% SEG_up: Maximum length of segment.
% SEG_down: Minimum length of segment.

   %**********************Calculate shape quality evaluation value efore moving a cut point***************************************
   cost=[];
   left=dtw(WSMVT(1,recut(1):recut(2)),repopulation_center.(['center' num2str(center_index(1))]),0); 
   right=dtw(WSMVT(1,recut(2):recut(3)),repopulation_center.(['center' num2str(center_index(2))]),0); 
   cost=(left+right+abs(left-right))/2; 
   allcost=[];

    %******************Bayesian 1-dimensional optimization****************************************************
    global Recut2D;
    Recut2D=recut;
    var = optimizableVariable('vx',[recut(1)+SEG_down-1,recut(3)-SEG_down+1]); 
    fun =@(x) my_sixmin2D(x.vx,WSMVT,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,center_index);
    results = bayesopt(fun,var,'PlotFcn',[],'Verbose',0,'MaxObjectiveEvaluations',10,'XConstraintFcn',@xconstraint2D);
    x=results.XAtMinObjective.vx;  
    y=results.MinObjective; 
   %************************************************************************************
   if y>cost
       COST=cost;
   else
       mutation_population_variation(1,recut(2))=0; % Eliminate the original cut point.
       mutation_population_variation(1,round(x))=1; % Reset the cut point
       COST=y;
   end
end



