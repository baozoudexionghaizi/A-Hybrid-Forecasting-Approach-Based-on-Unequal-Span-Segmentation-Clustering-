function z = my_sixmin3D(x,y,speed_train,recut,repopulation_center,repopulation_U)
%% *******The function of Bayesian 2-dimensional optimization*****************
% x: Expected cut point searched by Bayesian 2-dimensional optimization
% y: Expected cut point searched by Bayesian 2-dimensional optimization
% z: shape quality evaluation value after after moving a cut point.
% recut: Three consecutive cut points A, B, and C of mutation_population_variation.
% repopulation_center: Shape centers.
% repopulation_U: Membership matrix provided by FCM.

    x=round(x);
    y=round(y);
   allcost=[];
   allcost1=[];
   Allcost=[];
   for i=1:1:size(repopulation_U,1)
    left=dtw(speed_train(1,recut(1):x),repopulation_center.(['center' num2str(i)]),0); 
     for j=1:1:size(repopulation_U,1)
       mid=dtw(speed_train(1,x:y),repopulation_center.(['center' num2str(j)]),0); 
               for z=1:1:size(repopulation_U,1)
                  right=dtw(speed_train(1,y:recut(3)),repopulation_center.(['center' num2str(z)]),0); 
                  allcost=[allcost;  (left+right+mid+abs(left-right)+abs(left-mid)+abs(mid-right))/3 i j z x y left mid right];  
               end
      allcost1=[allcost1;allcost];
      allcost=[];
     end
       Allcost=[Allcost;allcost1];
       allcost1=[];
   end
   z=min(Allcost(:,1));
end
