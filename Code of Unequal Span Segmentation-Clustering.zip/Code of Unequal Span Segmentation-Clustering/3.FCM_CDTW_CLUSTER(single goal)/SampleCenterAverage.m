function [CENTER] = SampleCenterAverage(data,clusterrecord)
%% Calculate the average of all trend segments of unequal length in the time series set S.
Rearrangesequence=[];
RearrangeSEG=[];
CENTER=[];
for i=1:1:size(clusterrecord,1)
    Rearrangesequence=[Rearrangesequence,data(1,clusterrecord(i,1):1:clusterrecord(i,2))];
    if i==1
        RearrangeSEG=[RearrangeSEG;1 size(Rearrangesequence,2) clusterrecord(1,3)];
    else
        RearrangeSEG=[RearrangeSEG;RearrangeSEG(i-1,2)+1 size(Rearrangesequence,2) clusterrecord(i,3)];
    end
end

Dist=[]; 
C=[];
%**************************************************
if size(clusterrecord,1)~=1 
  %***********************************************

    for i=1:1:size(RearrangeSEG,1)-1
        for j=i+1:1:size(RearrangeSEG,1)
          Dist=[Dist;i j dtw(Rearrangesequence(1,RearrangeSEG(i,1):RearrangeSEG(i,2)),Rearrangesequence(1,RearrangeSEG(j,1):RearrangeSEG(j,2)),0)];
        end
    end
  %*************************************************
  %
 while size(RearrangeSEG,1)>1
    [~,index]=min(Dist(:,3)); 
    t=Dist(index,1);  
    r=Dist(index,2);  
    C=CDTW(Rearrangesequence,t,r,RearrangeSEG);
   C_membership=RearrangeSEG(t,3)+RearrangeSEG(r,3);         
%     C_membership=(RearrangeSEG(t,3)/(RearrangeSEG(t,3)+RearrangeSEG(r,3)))*RearrangeSEG(r,3)+(RearrangeSEG(r,3)/(RearrangeSEG(t,3)+RearrangeSEG(r,3)))*RearrangeSEG(t,3);
  %***************************************************
    if size(RearrangeSEG,1)~=2
    
        RearrangeSEG=[RearrangeSEG;RearrangeSEG(end,2)+1 RearrangeSEG(end,2)+size(C,2) C_membership];
        Rearrangesequence=[Rearrangesequence ,C];
 
    for i=1:1:size(RearrangeSEG,1)-1
        Dist=[Dist; i size(RearrangeSEG,1) dtw(Rearrangesequence(1,RearrangeSEG(i,1):RearrangeSEG(i,2)),Rearrangesequence(1,RearrangeSEG(size(RearrangeSEG,1),1):RearrangeSEG(size(RearrangeSEG,1),2)),0)];
    end
  
     Dist(find(Dist(:,1)==t),:)=[];
     Dist(find(Dist(:,1)==r),:)=[];
     Dist(find(Dist(:,2)==t),:)=[];
     Dist(find(Dist(:,2)==r),:)=[];
     Dist(find(Dist(:,1)>r),1)=Dist(find(Dist(:,1)>r),1)-1;
     Dist(find(Dist(:,2)>r),2)=Dist(find(Dist(:,2)>r),2)-1;
     Dist(find(Dist(:,1)>t),1)=Dist(find(Dist(:,1)>t),1)-1;
     Dist(find(Dist(:,2)>t),2)=Dist(find(Dist(:,2)>t),2)-1;
    
    Rearrangesequence([RearrangeSEG(r,1):RearrangeSEG(r,2) RearrangeSEG(t,1):RearrangeSEG(t,2)])=[]; 
    for j=[t,r]
     RearrangeSEG(j+1:1:end,1:2)=RearrangeSEG(j+1:1:end,1:2)-(RearrangeSEG(j,2)-RearrangeSEG(j,1))-1;
    end  
    RearrangeSEG([t,r],:)=[];
    end
  %*************************************************
    if size(RearrangeSEG,1)==2
        RearrangeSEG(1:1:end,:)=[];
    end
 end
 %% CDTW 
   if size(C,2)==1 
        error('********The value of CDTW output is wrong********');  
   end
   if  size(C,1)~=1
       error('********The value of CDTW output is wrong********');  
   end
   CENTER=C;
else   
   CENTER=data(1,clusterrecord(1,1):1:clusterrecord(1,2));    
   CENTER=zscore(CENTER);
end

end

