function [U_new,center,obj_fun]=FCMstep(data,segrecord,U,n,expo,center)
Record=find(segrecord==1);
dist=[];
Dist=[];
Dist_junzhi=0;
Dist1=0;
Dist2=0;
Dist3=0;
Dist4=0;
%% 
clusterrecord=[];
center1=[];
if n>=1
index1=find(U(1,:)==max(U));
    if size(index1,2)==0
         fprintf('********The category is empty, but reserved********'); 
         center1=center.center1;
    else
         for i=1:1:size(index1,2)
         clusterrecord=[clusterrecord; Record(1,index1(i)), Record(1,index1(i)+1), U(1,index1(i))];
        end
        center1=SampleCenterAverage(data,clusterrecord); 
        for i=1:1:size(Record,2)-1
        dist=[dist,dtw(data(1,Record(1,i):1:Record(1,i+1)),center1,0)];
        end
        Dist=[Dist;dist];
        center.center1=center1;
    end     
       
end
clusterrecord=[];
dist=[];
center2=[];
if n>=2
index2=find(U(2,:)==max(U)); 
    if size(index2,2)==0
         fprintf('********The category is empty, but reserved********'); 
         center2=center.center2;
    else
       for i=1:1:size(index2,2)
        clusterrecord=[clusterrecord; Record(1,index2(i)), Record(1,index2(i)+1), U(1,index2(i))];
       end
       center2=SampleCenterAverage(data,clusterrecord); 
        for i=1:1:size(Record,2)-1
        dist=[dist,dtw(data(1,Record(1,i):1:Record(1,i+1)),center2,0)];
        end
        Dist=[Dist;dist];
        center.center2=center2;
    end
end
clusterrecord=[];
dist=[];
center3=[];
if n>=3  
index3=find(U(3,:)==max(U)); 
    if size(index3,2)==0
          fprintf('********The category is empty, but reserved********');  
          center3=center.center3;
    else
        for i=1:1:size(index3,2)
         clusterrecord=[clusterrecord; Record(1,index3(i)), Record(1,index3(i)+1), U(1,index3(i))];
        end
        center3=SampleCenterAverage(data,clusterrecord);              
        for i=1:1:size(Record,2)-1
        dist=[dist,dtw(data(1,Record(1,i):1:Record(1,i+1)),center3,0)];
        end
        Dist=[Dist;dist];
        center.center3=center3;
    end
end
clusterrecord=[];
dist=[];
center4=[];
if n>=4
index4=find(U(4,:)==max(U));
    if size(index4,2)==0
          fprintf('********The category is empty, but reserved********');  
          center4=center.center4;
    else
        for i=1:1:size(index4,2)
         clusterrecord=[clusterrecord; Record(1,index4(i)), Record(1,index4(i)+1), U(1,index4(i))];
        end
        center4=SampleCenterAverage(data,clusterrecord);             
        for i=1:1:size(Record,2)-1
        dist=[dist,dtw(data(1,Record(1,i):1:Record(1,i+1)),center4,0)];
        end
        Dist=[Dist;dist];
        center.center4=center4;
    end
end
%% Calculate the objective function value
[value,index]=min(Dist);
obj_fun=sum(value)/(size(Record,2)-1);   
%% Update membership degree
tmp=Dist.^(-2/(expo-1));                
U_new=tmp./(ones(n,1)*sum(tmp));        
 
end

