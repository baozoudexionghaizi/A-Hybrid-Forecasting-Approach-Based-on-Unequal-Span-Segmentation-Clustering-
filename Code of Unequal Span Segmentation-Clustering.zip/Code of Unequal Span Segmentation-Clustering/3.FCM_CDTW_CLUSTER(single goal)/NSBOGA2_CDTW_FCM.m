function [P,F1] = NSBOGA2_CDTW_FCM( ...
    time_data, ...              
    SEG_down, ...               
    SEG_up, ...                 
    K, ...                      
    fitness_function, ...       
    population_size, ...        
    parent_number, ...          
    mutation_rate, ...          
    maximal_generation, ...     
    minimal_cost, ...            
    load_flag ... 
)
%
number_of_variables=size(time_data,2);
stopflag=0;
cumulative_probabilities = cumsum((parent_number:-1:1) / sum(parent_number:-1:1));
child_number = population_size - parent_number; 

%% Initialize population
population = zeros(population_size, number_of_variables); 
variate=SEG_up-SEG_down;
difference_record=round(rand(population_size,1000)*variate)+SEG_down.*ones(population_size,1000)-1; %���ɲ�������
difference_record=[ones(population_size,1) difference_record];
seg_record=difference_record;
for i=2:1:1001
seg_record(:,i)=sum(difference_record(:,1:1:i),2);
end
for i=1:1:population_size  
    for j=1:1:500   
       if seg_record(i,j) < number_of_variables 
           if number_of_variables - seg_record(i,j) >= SEG_down 
             population(i,seg_record(i,j))=1;
           else
                if (number_of_variables-seg_record(i,j-1))<SEG_up  
                    population(i,seg_record(i,j))=0;
                else
                    population(i,seg_record(i,j))=0;
                    population(i,seg_record(i,j-1)+floor((number_of_variables-seg_record(i,j-1))/2))=1; %ȡ�м�����µ��������
                end
           end
       end
    end
end
% Initial population detection
if size(find(population(:,end-SEG_down+1:1:end)),2)>1
   error('********Error in population initialization********');
end
population(:,end)=ones(population_size,1);
for i=1:1:population_size
    A=find(population(i,:)==1);
    for w=2:1:size(A,2)
       if A(1,w)-A(1,w-1)+1<SEG_down || A(1,w)-A(1,w-1)+1>SEG_up   
            error('********Error in population initialization********');
       end
    end
end

%% *********************Pareto sorting******************************
    individuVide.Val = [];
    individuVide.ValObjective = [];
    individuVide.Rank = [];
    individuVide.CrowdingDistance = [];
    individuVide.DominationSet = [];
    individuVide.DominatedCount = [];
    individuVide.PopulationSimilarCenter = [];
    individuVide.PopulationSpaceCenter = [];  
    individuVide.PopulationU = [];
    Pop = repmat(individuVide,population_size,1); 
    for pop_i=1:1:population_size
    Pop(pop_i).Val=population(pop_i,:); 
    end
%% initial individuals evaluation
% cost: the estimated value of loss function of all individuals.
% population_center: the cluster center of all individuals
% population_U: sample classification of all individuals
% Best_Center: the best center
% Best_U: the best classification

    generation=0; 
     for pop_i=1:1:population_size
        population(pop_i,:)=Pop(pop_i).Val;
     end
    [cost,population_similar_center,population_space_center,population_U]= feval(fitness_function, population,time_data,K,generation,parent_number); 
     for pop_i=1:1:population_size  
         Pop(pop_i).ValObjective=cost(pop_i,:)';
         Pop(pop_i).PopulationSimilarCenter=population_similar_center.(['population',num2str(pop_i)]);
         Pop(pop_i).PopulationSpaceCenter=population_space_center.(['population',num2str(pop_i)]);        
         Pop(pop_i).PopulationU=population_U.(['population',num2str(pop_i)]);
     end
    [Pop, F] = NonDominatedSorting(Pop);  %non-dominated sort
     P = CrowdingDistance(Pop,F);    %crowding distance calculation
    [P,~] = SortPopulation(P); 
    generation_record=[1,999];

for generation = 1:1:maximal_generation  
     Enfants=[];
    %% Copy all parent individuals to produce children
     Enfants=P;
    %% Chromosome crossing
    for child = 1:2:child_number 
        lowerlimit=1;
        while lowerlimit==1
        lowerlimit=-1;
        mother = find(cumulative_probabilities > rand, 1); 
        father = find(cumulative_probabilities > rand, 1); 
        crossover_point = ceil(rand*number_of_variables); 

        mask1 = [ones(1, crossover_point), zeros(1, number_of_variables - crossover_point)];
        mask2 = not(mask1);

        mother_1 = mask1 .* Enfants(mother).Val; 
        mother_2 = mask2 .* Enfants(mother).Val; 
        father_1 = mask1 .* Enfants(father).Val; 
        father_2 = mask2 .* Enfants(father).Val; 

        Child1=mother_1 + father_2;  
        Child2=mother_2 + father_1;

        if crossover_point-2*SEG_up+1 <= 1    
        Crossaround1=find(Child1(1,1:crossover_point+2*SEG_up-1)==1);
        Crossaround2=find(Child2(1,1:crossover_point+2*SEG_up-1)==1);
        elseif crossover_point+2*SEG_up-1 >= number_of_variables  
        Crossaround1=find(Child1(1,crossover_point-2*SEG_up+1:number_of_variables)==1);
        Crossaround2=find(Child2(1,crossover_point-2*SEG_up+1:number_of_variables)==1);
        else 
        Crossaround1=find(Child1(1,crossover_point-2*SEG_up+1:crossover_point+2*SEG_up-1)==1);
        Crossaround2=find(Child2(1,crossover_point-2*SEG_up+1:crossover_point+2*SEG_up-1)==1);        
        end
            
            for z=2:1:size(Crossaround1,2)
                if (Crossaround1(1,z)-Crossaround1(1,z-1)+1)<SEG_down || (Crossaround1(1,z)-Crossaround1(1,z-1)+1)>SEG_up
                    lowerlimit=1;
                end
            end
            for z=2:1:size(Crossaround2,2)
                if (Crossaround2(1,z)-Crossaround2(1,z-1)+1)<SEG_down || (Crossaround2(1,z)-Crossaround2(1,z-1)+1)>SEG_up
                    lowerlimit=1;
                end
            end
                  
        end
        
        Enfants(parent_number+child ).Val=[];
        Enfants(parent_number+child+1).Val=[];
        Enfants(parent_number+child).Val = mother_1 + father_2; 
        Enfants(parent_number+child+1).Val = mother_2 + father_1; 
    end  
    %% Genetic crossover is completed to check whether the variation is normal
not_right=[];
for i=1:1:population_size-parent_number
         jiaocha_population=Enfants(parent_number+child+i-1).Val;
         A=find(jiaocha_population==1);
         for w=2:1:size(A,2)
            if A(1,w)-A(1,w-1)+1<SEG_down || A(1,w)-A(1,w-1)+1>SEG_up
                not_right=[not_right,i];
            end
         end
end
if size(not_right,2)>0
 fprintf('****************************Error in length after chromosome crossing*********************\n');
end
   %% Chromosome mutation begins
     population=[];
    for pop_i=1:1:parent_number
        population(pop_i,:)=Enfants(pop_i).Val;
    end
     mutation_points_record=[]; 
     chongfupoints=[];
     max_times=2;
for bianyixunhuan=1:1:max_times  
    mutation_population = population(1:1:parent_number,:); 
    if bianyixunhuan==1
        mutation_population_pre=mutation_population; 
    end
    segmentation_of_elements=find(mutation_population==1);  
    segmentation_of_elements(1:1:parent_number)=[];    
    segmentation_of_elements(end-parent_number+1:1:end)=[];  
 
    number_of_mutations = ceil(size(segmentation_of_elements,1) * mutation_rate); 

    p=randperm(size(segmentation_of_elements,1));
    mutation_points=p(1:number_of_mutations); 

    IND=segmentation_of_elements(mutation_points);
    s=[size(mutation_population,1),size(mutation_population,2)];
    [I,J]=ind2sub(s,IND);
    I_new=[];
    B=unique(I);
    for kk=1:1:size(B,1)
        C=find(I==B(kk,1));
        I_new=[I_new;C(1,1)]; 
    end
    I=I(I_new,1);
    J=J(I_new,1);
    % prevent duplicate variation
    if bianyixunhuan~=1
        for j=1:1:size(I,1)
           for z=1:1:size(mutation_points_record,2) 
            if  I(j,1)==mutation_points_record(1,z) && J(j,1)==mutation_points_record(2,z)
                chongfupoints=[chongfupoints,j]; 
            end
           end
        end
        if size(chongfupoints,2)>0
            I(chongfupoints)=[]; %Delete the mutated mutation point.
            J(chongfupoints)=[]; %Delete the mutated mutation point.
            fprintf('Delete the mutated mutation point\n');
        end
  
    end
    %*************************BOMOs- mutation*****************************************
     global bestindex; 
     bestindex=[];
 for i=1:1:size(I,1)
     change_FLAG=1;
     mutation_population_variation=mutation_population(I(i),:); 
       if J(i)-2*SEG_up+1<=1     
          Nearpionts=find(mutation_population_variation(1,1:J(i)+2*SEG_up-1)==1);
       elseif J(i)+2*SEG_up-1>=size(mutation_population,2)
          Nearpionts=find(mutation_population_variation(1,J(i)-2*SEG_up+1:size(mutation_population,2))==1)+J(i)-2*SEG_up; 
       else
          Nearpionts=find(mutation_population_variation(1,J(i)-2*SEG_up+1:J(i)+2*SEG_up-1)==1)+J(i)-2*SEG_up; 
       end
     leftpiont=max(Nearpionts(Nearpionts<J(i)));  
     rightpiont=min(Nearpionts(Nearpionts>J(i))); 
     recut=[leftpiont,J(i),rightpiont];
     mutation_points_record=[mutation_points_record,[I(i)*ones(1,3); recut]]; 
     if size(recut,2)<3 
        fprintf('Error in variation range\n');
     end
     if recut(1,2)-recut(1,1)+1<SEG_down || recut(1,2)-recut(1,1)+1>SEG_up || recut(1,3)-recut(1,2)+1<SEG_down||recut(1,3)-recut(1,2)+1>SEG_up%��������?
        fprintf('Error in locating variation range\n');
     end
     reSegpoints=find(find(mutation_population_variation==1)==J(i)); 
     reSegpointsnumber=[reSegpoints-1,reSegpoints];  
     repopulation_U=Enfants(I(i)).PopulationU;
     repopulation_center=Enfants(I(i)).PopulationSimilarCenter;
    if recut(3)-recut(1)+1 <=3*SEG_down 
        mutation_population_variation_new=[];
        %% Remove cut point or BOMO-moving 
        [beter_recut1D,FinalCost1]= Segmentation1D(mutation_population_variation,reSegpointsnumber,recut,repopulation_center,repopulation_U,time_data,0);
        bestindex=[];    
        if recut(1)+SEG_down-1 ~= recut(3)-SEG_down+1 
        [beter_recut2D,FinalCost2]= Segmentation2D(mutation_population_variation,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,time_data,0);
        bestindex=[];
        else
        FinalCost2=FinalCost1+1;
        end
        if FinalCost1<FinalCost2
            mutation_population_variation_new=beter_recut1D;
            fprintf('Remove cut point\n');
        elseif FinalCost1==FinalCost2
            mutation_population_variation_new=beter_recut1D;
            fprintf('The mutation result is invalid and not retained\n');
        else
            mutation_population_variation_new=beter_recut2D;
            fprintf('BOMO-moving is retained\n');
        end
        %********************************
    else
        mutation_population_variation_new=[];
         [beter_recut3D,FinalCost3] = Segmentation3D(mutation_population_variation,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,time_data,0);
         bestindex=[]; 
        %%  BOMO-moving or Add a cut point 
        if recut(1)+SEG_down-1 ~= recut(3)-SEG_down+1 
          [beter_recut2D,FinalCost2] = Segmentation2D(mutation_population_variation,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,time_data,0);
         bestindex=[]; 
        else
            FinalCost2=FinalCost3+1;
        end
         %�ж�ѡ����һ�ֱ���������� 
         if FinalCost2<=FinalCost3
            mutation_population_variation_new=beter_recut2D;
            fprintf('BOMO-moving is retained\n');
         elseif FinalCost2==FinalCost3
            mutation_population_variation_new=beter_recut2D;
            fprintf('The mutation result is invalid and not retained\n');
         else
            mutation_population_variation_new=beter_recut3D;
            fprintf('BOMO-adding is retained\n');
         end
         %***********************
    end 
     %��ⳤ�������Ƿ�����
         A=find(mutation_population_variation_new==1);
         for w=2:1:size(A,2)
            if A(1,w)-A(1,w-1)+1<SEG_down || A(1,w)-A(1,w-1)+1>SEG_up
                change_FLAG=0;
                fprintf('The total number of genes that need to be mutated is %d,The mutation length of the %d gene is abnormal, and the chromosome is not mutated \n',size(I,1),i);
            end
         end
         if size(mutation_population_variation_new,2)<1  
         end
         if change_FLAG==1
             mutation_population_pre(I(i),leftpiont:1:rightpiont)= mutation_population_variation_new(1,leftpiont:1:rightpiont);%��Ӧ����α����滻
            fprintf('The %d round of mutation, the total number of chromosome gene mutations =%d, the %d gene mutation: success \n',bianyixunhuan,size(I,1),i);
         end        
 end
         %% Each round of mutation is completed to check whether the mutation is normal.
        not_right=[];
        for i=1:1:size(mutation_population_pre,1)
                 A=find(mutation_population_pre(i,:)==1);
                 for w=2:1:size(A,2)
                    if A(1,w)-A(1,w-1)+1<SEG_down || A(1,w)-A(1,w-1)+1>SEG_up
                        not_right=[not_right,i];
                    end
                 end
        end

end

 %% End of the BOMOs- mutation

    for pop_i=1:1:parent_number
        Enfants(pop_i).Val=mutation_population_pre(pop_i,:);
        population_center_new.(['population' num2str(pop_i)])=Enfants(pop_i).PopulationSimilarCenter;
    end
    
    global center_bianyi_sent;  
    center_bianyi_sent=population_center_new;
    % ************************************
    population=[];
    for pop_i=1:1:population_size
        population(pop_i,:)=Enfants(pop_i).Val;
    end
    %% Evaluate the samples of offspring   
        [cost,population_similar_center,population_space_center,population_U]= feval(fitness_function, population,time_data,K,generation,parent_number); % ��һ�μ������и������Ӧ�ȣ�population_size*1�ľ���    
     for pop_i=1:1:population_size  
         Enfants(pop_i).ValObjective=cost(pop_i,:)';
         Enfants(pop_i).PopulationSimilarCenter=population_similar_center.(['population',num2str(pop_i)]);
         Enfants(pop_i).PopulationSpaceCenter=population_space_center.(['population',num2str(pop_i)]);        
         Enfants(pop_i).PopulationU=population_U.(['population',num2str(pop_i)]);
     end
    %% Merge Parent and Child Individuals
    Pop=[];
    Pop=[P;Enfants];
    [Pop, F] = NonDominatedSorting(Pop);  
     Pop = CrowdingDistance(Pop,F);  
     [Pop,~] = SortPopulation(Pop); 

     Pop=Pop(1:1:population_size,:);
    [Pop, F] = NonDominatedSorting(Pop); 
     Pop = CrowdingDistance(Pop,F); 
     [P, F] = SortPopulation(Pop);
    F1 = P(F{1}); 
    AffichageResultats(F1, generation);  

    fprintf('GDK:Iteration generation=%d\n',generation);
    for show_i=1:1:size(F1,1)
    fprintf('obj_fun1=%f,obj_fun2=%f\n',F1(show_i).ValObjective(1,1),F1(show_i).ValObjective(2,1));   
        if F1(show_i).ValObjective(1,1)<= minimal_cost
            stopflag=1;  
        end
    end
    %% End of population evolution
    generation_record=[generation_record;[generation_record(end,1)+1,size(F1,1)]];
    if stopflag==1
        save P P;
        save F1 F1;
        save generation_record generation_record;
        break;
    end
        save P P;
        save F1 F1;
        save generation_record generation_record;
    
end

end

