function [y,population_similar_center,population_space_center,population_U]= my_fitness(population,time_data,K,generation,parent_number)
population_similar_center=[]; 
population_space_center=[]; 
population_U=[];
y=zeros(size(population,1),2);
options = [2;1;1e-7;1]; 
for i=1:1:size(population,1)
segrecord=population(i,:);  
[best_similar_center,best_U,best_similar_obj_fun] = FCM_CDTW_Cluster(time_data,segrecord,K,generation,i,parent_number,options); 
[best_space_center,best_space_obj_fun]=FCM_real_distance_step(time_data,segrecord,best_U,K);
%********************************************
y(i,1)=best_similar_obj_fun;
y(i,2)=best_space_obj_fun;
%********************************************
population_similar_center.(['population' num2str(i)])=best_similar_center;   
population_space_center.(['population' num2str(i)])=best_space_center;
population_U.(['population' num2str(i)])=best_U;    
%********************************************************
fprintf('FCM: %d chromosomes in total, the %d chromosome has been segmented and clustered \n',size(population,1),i);
end

