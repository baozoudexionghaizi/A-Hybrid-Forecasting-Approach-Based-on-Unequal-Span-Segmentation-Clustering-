function z = my_sixmin3D_match(x,y,speed_train,recut,center,K)
    x=round(x);
    y=round(y);
   allcost=[];
   allcost1=[];
   Allcost=[];
   for i=1:1:K
    left=dtw(speed_train(1,recut(1):x),center.(['center' num2str(i)]),0); %���������ڴ�������ƶ�
     for j=1:1:K
       mid=dtw(speed_train(1,x:y),center.(['center' num2str(j)]),0); %����Ҷ����ڴ�������ƶ�
               for z=1:1:K
                  right=dtw(speed_train(1,y:recut(3)),center.(['center' num2str(z)]),0); %����Ҷ����ڴ�������ƶ�   
%                   allcost=[allcost; left*mid*right i j z x y left mid right];
%                      allcost=[allcost;left+mid+right i j z x y left mid right];    %2019.09.30
%                     allcost=[allcost;((left+mid)/(left+mid+right)*right)+((mid+right)/(left+mid+right)*left)+((left+right)/(left+mid+right)*mid) i j z x y left mid right];       
                allcost=[allcost;  (left+right+mid)/3 i j z x y left mid right];  %2019.10.03
%            allcost=[allcost;  ((abs(left-mid)+0.1)/(left+mid)*left*mid)+((abs(mid-right)+0.1)/(mid+right)*mid*right) i j z x y left mid right];  %2019.10.03
               end
      allcost1=[allcost1;allcost];
      allcost=[];
     end
       Allcost=[Allcost;allcost1];
       allcost1=[];
   end
   z=min(Allcost(:,1));
  global bestindex; 
  bestindex=[];
  bestindex=[bestindex;Allcost];
end
