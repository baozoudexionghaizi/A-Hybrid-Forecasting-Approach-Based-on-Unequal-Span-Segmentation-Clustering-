function z = my_sixmin2D_match(x,speed_train,recut,center,K)
   x=round(x);
   allcost=[];
   Allcost=[];
   for i=1:1:K
    left=dtw(speed_train(1,recut(1):x),center.(['center' num2str(i)]),0); %���������ڴ�������ƶ�
     for j=1:1:K
      right=dtw(speed_train(1,x:recut(3)),center.(['center' num2str(j)]),0); %����Ҷ����ڴ�������ƶ�
%         allcost=[allcost;(left*right) i j x left right ];
%         allcost=[allcost;(left/(left+right)*right)+(right/(left+right)*left)   i j x left right];                                                    %2019.09.30
%          allcost=[allcost;left+right i j x left right];   
        allcost=[allcost; (left+right)/2   i j x left right]; %2019.10.03����
% allcost=[allcost;((abs(left-right)+0.1)/(left+right)*left*right) i j x left right];
     end
       Allcost=[Allcost;allcost ];
       allcost=[];
   end
   z=min(Allcost(:,1));
  global bestindex; 
  bestindex=[];
  bestindex=[bestindex;Allcost];
end

