%% Load data
clear all;
close all;
clc;
load ('speed_train_fit.mat');
%% Unequal Span Segmentation-Clustering
  [P,F1] = NSBOGA2_CDTW_FCM( ...
    speed_train_fit, ...              % wind speed series
    8, ...               % Lower Limit of Span 
    24, ...                 % Upper limit Span 
    4, ...                      % Cluster number
    @my_fitness, ...       % Shape-position comprehensive evaluation function
    30, ...        % Population size
    4, ...          % The number that remains constant in each generation
    0.5, ...          % BMOS-mutation probability
    1000, ...     % Maximum evolution generation
    2, ...            % Minimum target value
    0 ... 
);
%% Result extraction
Speed_train=speed_train_fit;
Front=P;
ValObjPF = [Front.ValObjective];
x_min_vale=min(ValObjPF(1,:));
[x_max_vale,x_index]=max(ValObjPF(1,:));
y_min_vale=min(ValObjPF(2,:));
[y_max_vale,y_index]=max(ValObjPF(2,:));
X=[];
Y=[];
for i=1:1:size(ValObjPF,2)
X=[X,(ValObjPF(1,i)-x_min_vale)/(x_max_vale-x_min_vale)];
Y=[Y,(ValObjPF(2,i)-y_min_vale)/(y_max_vale-y_min_vale)];
end
D=[];
for i=1:1:size(ValObjPF,2)
    D=[D,sqrt(X(1,i)^2+Y(1,i)^2)];
end
[number,g_index]=min(D); 

disp( [' // Taille Front = ' ,num2str(size(Front,1))]);
figure;
plot(ValObjPF(1,:),ValObjPF(2,:),'x');
hold on;
plot(ValObjPF(1,[y_index,g_index,x_index]),ValObjPF(2,[y_index,g_index,x_index]),'ro','LineWidth',1.5);
xlabel('Shape similarity fitness vale');
ylabel('Position similarity vale');
grid on;
pause(0.01);
Importantpointnumber_Y_G_X=[y_index,g_index,x_index];


best_jieguo=Front(4);
seg_record=best_jieguo.Val;
Similarcenter=best_jieguo.PopulationSimilarCenter;
SpaceCenter=best_jieguo.PopulationSpaceCenter;
center_record=best_jieguo.PopulationU;

%% Extract clustering results
index1=find(center_record(1,:)==max(center_record)); 
index2=find(center_record(2,:)==max(center_record)); 
index3=find(center_record(3,:)==max(center_record)); 
index4=find(center_record(4,:)==max(center_record)); 
suoying=find(seg_record==1);

%% Display clustering result 
subplot(2,2,1);
for i=1:1:size(index1,2)
hold on;
x=size(suoying(1,index1(i)):suoying(1,index1(i)+1),2);
plot((1:1:x)-floor(x/2),Speed_train(1,suoying(1,index1(i)):suoying(1,index1(i)+1)),'b-','linewidth',1);
end
hold on;
center=SpaceCenter.center1;

plot((1:1:size(Similarcenter.center1,2))-(floor(size(Similarcenter.center1,2)/2)),Similarcenter.center1+center,'r-','linewidth',3);
hold on;
plot(0,center,'go','linewidth',3);
box on;
ylabel('Wind speed (m/s)');
title('Cluster c - 1','position',[0,-6]);
axis([-15 15 0 22]);
%% ********************************************
subplot(2,2,2);
for i=1:1:size(index2,2)
hold on;
x=size(suoying(1,index2(i)):suoying(1,index2(i)+1),2);
plot((1:1:x)-floor(x/2),Speed_train(1,suoying(1,index2(i)):suoying(1,index2(i)+1)),'b-','linewidth',1);
end
hold on;
center=SpaceCenter.center2;

plot((1:1:size(Similarcenter.center2,2))-(floor(size(Similarcenter.center2,2)/2)),Similarcenter.center2+center,'r-','linewidth',3);
hold on;
plot(0,center,'go','linewidth',3);
% grid on
box on;
ylabel('Wind speed (m/s)');
title('Cluster c - 2','position',[0,-6]);
axis([-15 15 0 22]);
%% **********************************
subplot(2,2,3,'position',[0.08,0.1,0.4,0.3]);
subplot(2,2,3);
for i=1:1:size(index3,2)
hold on;
x=size(suoying(1,index3(i)):suoying(1,index3(i)+1),2);
plot((1:1:x)-floor(x/2),Speed_train(1,suoying(1,index3(i)):suoying(1,index3(i)+1)),'b-','linewidth',1);
end
hold on;
center=SpaceCenter.center3;

plot((1:1:size(Similarcenter.center3,2))-(floor(size(Similarcenter.center3,2)/2)),Similarcenter.center3+center,'r-','linewidth',3);
hold on;
plot(0,center,'go','linewidth',3);
% grid on
box on;
ylabel('Wind speed (m/s)');
title('Cluster c - 3','position',[0,-6]);
axis([-15 15 0 22]);
%% ********************************************
subplot(2,2,4);
for i=1:1:size(index4,2)
hold on;
x=size(suoying(1,index4(i)):suoying(1,index4(i)+1),2);
plot((1:1:x)-floor(x/2),Speed_train(1,suoying(1,index4(i)):suoying(1,index4(i)+1)),'b-','linewidth',1);
end
hold on;
center=SpaceCenter.center4;

plot((1:1:size(Similarcenter.center4,2))-(floor(size(Similarcenter.center4,2)/2)),Similarcenter.center4+center,'r-','linewidth',3);
hold on;
plot(0,center,'go','linewidth',3);
% grid on
box on;
ylabel('Wind speed (m/s)');
title('Cluster c - 4','position',[0,-6]);
axis([-15 15 0 22]);
