function z = my_sixmin2D(x,speed_train,reSegpointsnumber,recut,repopulation_center,repopulation_U,SEG_up,SEG_down,index)
   x=round(x);
   allcost=[];
   Allcost=[];
   for i=1:1:size(repopulation_U,1)
    left=dtw(speed_train(1,recut(1):x),repopulation_center.(['center' num2str(i)]),0); %���������ڴ�������ƶ�
     for j=1:1:size(repopulation_U,1)
      right=dtw(speed_train(1,x:recut(3)),repopulation_center.(['center' num2str(j)]),0); %����Ҷ����ڴ�������ƶ�
%         allcost=[allcost;(left*right) i j x left right ];
%         allcost=[allcost;(left/(left+right)*right)+(right/(left+right)*left)   i j x left right];                                                    %2019.09.30
%           allcost=[allcost;left+right i j x left right];   
       allcost=[allcost; (left+right+abs(left-right))/2   i j x left right]; %2019.11.22
%    allcost=[allcost; ((abs(left-right)+0.1)/(left+right)*left*right)   i j x left right]; %2019.11.22��
     end
       Allcost=[Allcost;allcost ];
       allcost=[];
   end
   z=min(Allcost(:,1));
  global bestindex; 
  bestindex=[];
  bestindex=[bestindex;Allcost];
  
  %%  2019.12.13��
%    x=round(x);
%    Allcost=[];
%   left=dtw(speed_train(1,recut(1):x),repopulation_center.(['center' num2str(index(1))]),0); %���������ڴ�������ƶ�
%   right=dtw(speed_train(1,x:recut(3)),repopulation_center.(['center' num2str(index(2))]),0); %����Ҷ����ڴ�������ƶ�
%   Allcost=left+right+abs(left-right);
%    z=Allcost;
%   global bestindex; 
%   bestindex=[];
%   bestindex=[bestindex;Allcost];
end

