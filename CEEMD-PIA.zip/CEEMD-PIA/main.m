clear all;
close all;
load ('Data/Speedhour.mat');
Speedhour=Speedhour';
data=Speedhour;
[z_iter,z_final,pos_final,optimal_pos,modes,PS,OptimizationRecord]=NWSSR_good(data);

z_iter=z_iter(:,1);
pp=pos_final(:,1)';

[A,B,fit_output] = jieguo(pp);

figure
plot(PS(:,1),PS(:,2),'ro','LineWidth',2,'Markersize',8);
hold on;
plot(OptimizationRecord(:,4),OptimizationRecord(:,5),'bo','LineWidth',0.5,'Markersize',8);
hold on;
plot(A,B,'go','LineWidth',2,'Markersize',8);
hold on;
plot(PS(:,1),PS(:,2),'ro','LineWidth',2,'Markersize',8);



legend('Boundary solutions','Searched solutions','Best solution');

hold on;
plot([PS(1,1);A],[PS(1,2);B],'r-.','LineWidth',1);
hold on;
plot([PS(2,1);A],[PS(2,2);B],'r-.','LineWidth',1);

xianshifanwei=[0,3650];
jiange=100;

hold on;
plot(A+jiange:xianshifanwei(2)-jiange,B*ones(1,xianshifanwei(2)-A+1-2*jiange),'k-.','LineWidth',1);
hold on;
plot(xianshifanwei(1)+jiange:A-jiange,B*ones(1,A-xianshifanwei(1)+1-2*jiange),'k-.','LineWidth',1);

box on;
ylabel('Deviation (KW)','FontSize',12);
xlabel('The number of the piecewise points','FontSize',12);

axis([xianshifanwei 0.5 4.1]);

figure
plot(data,'b-');
hold on;
plot(fit_output,'r-');



figure
plot(z_iter,'r-','LineWidth',1.5);
box on;
ylabel('Rising rate of the deviation','FontSize',18);
xlabel('Iteration','FontSize',18);
legend('R');
axis([0 length(z_iter) z_iter(end) z_iter(1)]);


figure
plot(round(optimal_pos(:,1))-1,'b-','LineWidth',1.5);
hold on;
plot(optimal_pos(:,2),'g-','LineWidth',1.5);
hold on;
plot(optimal_pos(:,3),'m-','LineWidth',1.5);
box on;
ylabel('Value of the parameter','FontSize',18);
xlabel('Iteration','FontSize',18);

legend('m','T_v','T_t');


% figure
% plot(optimal_pos(:,2),'b-');
% figure
% plot(optimal_pos(:,3),'b-');




